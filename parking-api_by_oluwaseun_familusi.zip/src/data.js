const data = [
    {
        id: 1,
        name: 'Bertie Yates',
        age:29,
        image: 'https://res.cloudinary.com/dwwte6hoj/image/upload/v1690646607/cld-sample-5.jpg',
    },
    {
        id: 2,
        name: 'Hester Hogan',
        age:32,
        image: 'https://res.cloudinary.com/dwwte6hoj/image/upload/v1690646605/cld-sample.jpg',
    },
    {
        id: 3,
        name: 'Larry Little',
        age:36,
        image: 'https://res.cloudinary.com/dwwte6hoj/image/upload/v1690646604/samples/man-on-a-street.jpg',
    }

];

export default data;
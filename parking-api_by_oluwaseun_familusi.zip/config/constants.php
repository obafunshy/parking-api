<?php

return [
    "WEEKDAY_PRICE" => env('WEEKDAY_PRICE', 2),
    "WEEKEND_PRICE" => env('WEEKEND_PRICE', 3),
    "SUMMER_PRICE" => env('SUMMER_PRICE', 5),
    "WINTER_PRICE" => env('WINTER_PRICE', 6),
    "TOTAL_PARKING" => env('TOTAL_PARKING', 10),
];
